# -*- coding: utf-8 -*-



####################################################
####             MAIN PARAMETERS                ####
####################################################
SimulateData  = True          # If False denotes training the CNN with SEGSaltData
ReUse         = False         # If False always re-train a network 
DataDim       = [2000,300]    # Dimension of original one-shot seismic data
data_dsp_blk  = (5,1)         # Downsampling ratio of input
ModelDim      = [100,300]     # Dimension of one velocity model
label_dsp_blk = (1,1)         # Downsampling ratio of output
dh            = 10            # Space interval 


####################################################
####             NETWORK PARAMETERS             ####
####################################################

    Epochs        = 800       # Number of epoch
    TrainSize     = 200      # Number of training set
    TestSize      = 1       # Number of testing set
    TestBatchSize = 1

    
BatchSize         = 4        # Number of batch size
LearnRate         = 1e-4      # Learning rate
Nclasses          = 1         # Number of output channels
Inchannels        = 5        # Number of input channels, i.e. the number of shots
SaveEpoch         = 20        
DisplayStep       = 2         # Number of steps till outputting stats
